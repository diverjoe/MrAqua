********************************************
CONTACT INFO
********************************************

PROJECT:    	iAqua shield
DOC CONTROL:    iAqua_Mega_Shield.zip
Revision:   	1
Date:       	2015/3/3
AUTHOR:     	Ryan Truss

*******************************************
PCB MATERIAL SPECIFICAITONS
*******************************************
MATERIAL:       FR-4
THICKNESS:      0.062" (1/16"/1.575mm)
UL TEMPERATURE:     130�C
UL FLAMMABILITY:    94 V-0
UL CTI:         >=175 (PLC 3 or better)


*******************************************
CONSTRUCTION SUMMARY
*******************************************

----------
DIMENSIONS
----------
Board Dimensions:   100.0mm x 100.0mm
(does not include handling rails)
     

------
LAYERS
------
No. of copper layers:   	2
Component Ident Top Colour: 	White
Component Ident Bottom Colour:  White
Solder Mask Top:        	Matte Green LPI
Solder Mask Bottom:     	Matte Green LPI

----------
MECHANICAL
----------
Number of Holes:    384
Smallest hole:      0.5mm
Largest Hole:       4mm
Number of Drills:   8
Blind vias:         N/A
Buried vias:        N/A
Non Plated Holes:   355 


-------------
COPPER WEIGHT
-------------
Internal base:      N/A
Internal plate:     N/A
External base:      0.5oz
External plate:     0.7oz
Through Hole plating:   IPC-6012 current version, Class 2 (Average 20um, Thin Area 18um) 

--------------
COPPER PATTERN
--------------
Surface Mount Side(s):  2
Smallest Pitch:     	0.65mm
Min Track Width:    	0.010"
Min Track Spacing:  	0.007"
Min Annular Ring:   	0.010"
Finish:         SMOBC
Pad finish:     Reference P.O. (Lead free HASL, Immersion Silver, ENIG)


*******************************************
OTHER INSTRUCTIONS
*******************************************

Acceptability of Printed Boards:    IPC-A-600 CURRENT REVISION, CLASS-2 


*******************************************
LAYER STACKUP
*******************************************

N/A



******************************************************************************************
Gerber File Extension

Layer Extension     Layer Description
******************************************************************************************

Add and delete extensions as deemed appropriate

.GTL                Top Layer
.GTO                Top Overlay
.GTS                Top Solder Mask
.GD1                Drill Drawing
.GG1                Drill Guide
.apr                Aperature
.GBL                Bottom Layer
.GBO                Bottom Overlay
.GBS                Bottom Solder Mask
.GKO		    Board Outline

******************************************************************************************

*******************************************
PACKAGE FILE CONTENTS
*******************************************

PCB_Readme.txt  This file



Gerber Files
******************************************************************************************

iAqua_Mega_Shield.GTL                Top Layer
iAqua_Mega_Shield.GTO                Top Overlay
iAqua_Mega_Shield.GTS                Top Solder Mask
iAqua_Mega_Shield.GD1                Drill Drawing
iAqua_Mega_Shield.GG1                Drill Guide
iAqua_Mega_Shield.apr                Aperature
iAqua_Mega_Shield.GBL                Bottom Layer
iAqua_Mega_Shield.GBO                Bottom Overlay
iAqua_Mega_Shield.GBS                Bottom Solder Mask
iAqua_Mega_Shield.GKO		     Board Outline

******************************************************************************************


Dril Files
******************************************************************************************

iAqua_Mega_Shield.DRR
iAqua_Mega_Shield.TXT

******************************************************************************************

Mechanical Drawing
******************************************************************************************
See .GG1 for Mechanical detail 


******************************************************************************************

Schematic
******************************************************************************************


